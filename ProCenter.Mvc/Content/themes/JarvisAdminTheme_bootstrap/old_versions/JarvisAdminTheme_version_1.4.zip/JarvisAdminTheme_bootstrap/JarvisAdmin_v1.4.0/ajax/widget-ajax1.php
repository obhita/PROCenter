<div class="inner-spacer">  
<!-- dummy file -->
<p>data-widget-load="widget-ajax2.php"</p>
<div class="spacer-10"></div>
<div class="powerwidget-timestamp"></div>
</div>