<div class="inner-spacer">  
<!-- dummy file -->
<p>Lorem ipsum.......</p>
</div> 