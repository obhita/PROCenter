You should be able to control and manipulate most of the basic components by editing Variable.less file. Please note on IE8, you will not be able to see the media queries.

This was a turn around conversion from CSS to LESS due to the popular demand for a LESS version of Jarvis Theme. There will be significant improvements in the future of the LESS file. 